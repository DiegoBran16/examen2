/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.url.examen2.problema2;

/**
 *
 * @author diego
 */
public class main {
    public static void main (String[] args){
        

        DemostracionLista p = new DemostracionLista();
       p.crearDemoLista();
    }
    
}
