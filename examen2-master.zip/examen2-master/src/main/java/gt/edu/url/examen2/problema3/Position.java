package gt.edu.url.examen2.problema3;

public interface Position<E> {
	
	E getElement() throws IllegalStateException;

}
