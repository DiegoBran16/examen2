package gt.edu.url.examen2.problema4;

public interface Position<E> {
	
	E getElement() throws IllegalStateException;

}
