/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.url.examen2.problema3;


/**
 *
 * @author diego
 */
public class main {
    /**
     * 
     * 
     * @param args 
     */
    public static void main(String[] args){
        
        LinkedPositionalList<Integer> Lista =new LinkedPositionalList<>();
        Position<Integer> p0,p,p1,q,q1;
        p0=Lista.addFirst(1);
        p1=Lista.addAfter(p0,2);
        p=Lista.addAfter(p1,3);
        p=Lista.addAfter(p,4);
        p1=Lista.addAfter(p, 5);
        p1=Lista.addAfter(p1, 6);
        q=Lista.addAfter(p1,7);
        q=Lista.addAfter(q,8);
        Lista.swap(p, q);
        int px=0;
        
           do {
            try{
            Position<Integer> posTemp=Lista.first();
            px=Lista.remove(posTemp);
            System.out.println(px);
            }
            catch(Exception e){
                System.out.println("fin de la lista");
                px=0;
                break;
            }
          
        }while(px!=0);
        
         
        
    }
    
}
