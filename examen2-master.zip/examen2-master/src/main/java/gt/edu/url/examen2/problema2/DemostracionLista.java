/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.url.examen2.problema2;

/**
 *
 * @author diego
 */
public class DemostracionLista implements DemoList{
        /**
         * 
         * @return retornq la lista con los elementos incertados
         */
     public List<Integer> crearDemoLista(){
         List<Integer> Lista= new ArrayList<>();
         Lista.add(0,4);
         Lista.add(0,3);
         Lista.add(0,2);
         Lista.add(2,1);
         Lista.add(1,5);
         Lista.add(1,6);
         Lista.add(3,7);
         Lista.add(0,8);
         return Lista;
     }
}
