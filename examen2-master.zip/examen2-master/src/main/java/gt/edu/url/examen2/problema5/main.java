/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.url.examen2.problema5;



/**
 *
 * @author diego
 */
public class main {
    /**
     * 
     * 
     * @param args 
     */
    public static void main(String[] args){
        
        DynamicStack<Integer> pila= new DynamicStack<>();
        pila.push(1);
        pila.push(2);
        pila.push(3);
        pila.push(4);
        do {
           System.out.println( pila.pop());
        }while(pila.isEmpty()!= true);
        
        
        
    }
    
}
